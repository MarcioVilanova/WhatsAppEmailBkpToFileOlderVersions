package policiacientifica.gov.pr.br.whatsappemailbackup5;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.provider.DocumentFile;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Date;

public class ReportActivity extends AppCompatActivity {

    // GLOBAL CONSTANTS

    // Constant to identify the Create Report Intent
    private static final int CREATE_REPORT = 5;

    // Constant for contacts.txt filename
    private static final String CONTACTS_FILENAME = "contacts.txt";

    // Constant for report.odt filename
    private static final String REPORT_FILENAME = "report.html";

    // GLOBAL VARIABLES

    // Output directory to save WhatsApp files
    private DocumentFile gObjDFPickedDir;

    /* ====================================================================================================
     =
     = Method      : onCreate
     = Description : to create all the GUI
     = Input       : --
     = Output      : -
     = OBS         : -
     =
  ======================================================================================================  */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Create the GUI
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

    } // End of onCreate

    /* ====================================================================================================
      =
      = Method      : closeReport
      = Description : to hide this activity
      = Input       : --
      = Output      : -
      = OBS         : -
      =
   ======================================================================================================  */
    public void closeReport(View view) {

        finish();

    } // End of closeReport routine

    /* ====================================================================================================
      =
      = Method      : initReport
      = Description : to initiate the Report creation process
      = Input       : --
      = Output      : -
      = OBS         : -
      =
   ======================================================================================================  */
    public void initReport(View view) {

        // Create the intent to create Report (where User must select a directory where WhatsApp text files are stored
        Intent objIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        objIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        // Call this Intent (and process it on onActivityResult routine)
        startActivityForResult(objIntent, CREATE_REPORT);

    } // End of closeReport routine

    /*
    =======================================================================================================
       =
       = Method      : onActivityResult
       = Description : to handle created Intents on the Main Activity
       = Input       : requestCode -> the code of the request (to identify which Intent called this one)
                       resultCode  -> whether is a result from an Intent
                       resultData  -> the Intent data
       = Output      : -
       = OBS         : -
       =
    ======================================================================================================
    */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {

        // Verify whether something was selected
        if (resultCode == RESULT_OK) {

            // Ok, user selected a Directory to FETCH the attachments, grab this data
            Uri objTreeUri = resultData.getData();

            // Fetch the directory selected
            gObjDFPickedDir = DocumentFile.fromTreeUri(this, objTreeUri);

            // Store this information in a pair of shared preferences data
            SharedPreferences objSharedPref = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor objEditor = objSharedPref.edit();
            objEditor.putString(getString(R.string.default_directory),objTreeUri.getPath());
            objEditor.commit();

            // Verify whether is something related to picking a Directory ONLY
            if (requestCode == CREATE_REPORT) {

                // Call the create report routine
                report_create();

            } // End of IF loop to handle  request

        } // End of IF loop to test whether some Intent really called this activity

    } // End of onActivityResult

    /* =================================================================================

     * ROUTINE     : strPrefix
     * DESCRIPTION : return the common prefix between two strings
     * INPUT       : -
     * OUTPUT      : the common prefix string
     * OBS         : throw exception when one of arguments are null
     *
     ================================================================================== */
    private String strPrefix(String pStrFirst, String pStrSecond) {

        // If one of the arguments are null, throw an exception
        if (pStrFirst == null || pStrSecond == null){
            throw new IllegalArgumentException();
        }

        int intMinLength = 0;

        // Find the minimum length of the two strings
        if (pStrFirst.length() < pStrSecond.length()){
            intMinLength = pStrFirst.length();
        }
        else{
            intMinLength = pStrSecond.length();
        }

        // Loop through all characters in the smallest string, to compare the first characters
        for (int i = 0 ; i < intMinLength ; i++){

            if(pStrFirst.charAt(i) == pStrSecond.charAt(i)){
                continue;
            }
            else{
                return pStrFirst.substring(0,i);
            }
        }

        return pStrFirst.substring(0,intMinLength);

    } // End of strPrefix

    /* =================================================================================

     * ROUTINE     : report_create
     * DESCRIPTION : create the Intent for selecting the Directory where all conversations
                        text files so it can create a report with all of them
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    public void report_create() {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        tvStatus.append("\n" + getString(R.string.report_init));

        // First check whether the global FileDocument is already set
        if (gObjDFPickedDir == null) {
            tvStatus.append("\n" + getString(R.string.output_directory_not_set));
            return;
        } // End of IF loop for verifying global FileDocument object

        // Fetch the Contacts file (created earlier, when exporting conversations)
        DocumentFile objTXTFiles = gObjDFPickedDir.findFile(CONTACTS_FILENAME);

        // if there are no WhatsApp contacts, tell user
        if (objTXTFiles == null)
            tvStatus.append("\n" + getString(R.string.contacts_not_found));

        // We have to study all the text filenames to find out which file prefix is related to the conversation files
        // For this, loop through all files ...
        tvStatus.append("\n" + getString(R.string.report_finding_prefix));
        DocumentFile[] objArrDocFile = gObjDFPickedDir.listFiles();

        // If there are no files, get out and tell user
        if (objArrDocFile.length == 0) {
            tvStatus.append("\n" + getString(R.string.no_text_files));
            return;
        }

        String strCommonPrefix = "";
        for (int i=0; i<objArrDocFile.length; i++) {

            // Study only text files (not consider the CONTACTS_FILENAME as well!!!)
            String strExtension = objArrDocFile[i].getName().substring(objArrDocFile[i].getName().lastIndexOf(".")+1,objArrDocFile[i].getName().length());
            if (strExtension.equals("txt") && !objArrDocFile[i].getName().equals(CONTACTS_FILENAME)) {

                if (strCommonPrefix.equals("")) {
                    strCommonPrefix = objArrDocFile[i].getName();
                } else {
                    strCommonPrefix = strPrefix(strCommonPrefix,objArrDocFile[i].getName());
                }

            } // End of IF loop for text files

        } // End of FOR loop for finding conversation file prefix

        // If no prefix was found, there is something very wrong, so tell the user
        if (strCommonPrefix.equals("")) {
            tvStatus.append("\n" + getString(R.string.report_prefix_not_found));
            return;
        }

        // Now the prefix for WhatsApp text files is known and there is at least one conversation file

        // Create an HTML file
        DocumentFile objFile = gObjDFPickedDir.createFile("text/html",REPORT_FILENAME);

        // Define the output stream for the file above
        OutputStream objOS;
        try {

            objOS = getContentResolver().openOutputStream(objFile.getUri());
        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.report_failed) + ": " + e.getMessage());
            return;
        }

        // Create the initial HTML tags and CSS styles...
        writeInitialReport(objOS);

        // Write the Contacts
        if (objTXTFiles != null) {
            writeContacts(objTXTFiles,objOS);
        }

        // Write additional tags for the conversation files
        String strLine;
        try {

            strLine = "<article>\n" +
                    "\t\t<h2>" + getString(R.string.report_title4)+ "</h2>";
            objOS.write(strLine.getBytes());

        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.report_failed) + ": " + e.getMessage());
            return;
        }

        // Loop through all file within the directory AGAIN
        for (int i=0; i<objArrDocFile.length; i++) {

            // Fetch only the conversation files now
            String strExtension = objArrDocFile[i].getName().substring(objArrDocFile[i].getName().lastIndexOf(".")+1,objArrDocFile[i].getName().length());
            if (strExtension.equals("txt") && objArrDocFile[i].getName().startsWith(strCommonPrefix)) {

                // Ok, it is a WhatsApp conversation file, so start reading...
                try {

                    // Write the initial tags for this specific conversation file
                    strLine = "<section>\n" +
                            "\t\t\t<h3>" + getString(R.string.report_file) + objArrDocFile[i].getName() + "</h3>\n" +
                            "\t\t\t<table>\n" +
                            "\t\t\t\t<tr>\n" +
                            "\t\t\t\t\t<td>";

                    objOS.write(strLine.getBytes());

                    // Create the Reading object for this specific conversation file
                    InputStream objIS = getContentResolver().openInputStream(objArrDocFile[i].getUri());
                    BufferedReader objBR = new BufferedReader(new InputStreamReader(objIS));

                    // loop through all the lines in this conversation file
                    while ((strLine = objBR.readLine()) != null) {

                        strLine = strLine + "<br>";

                        objOS.write(strLine.getBytes());

                    } // End of WHILE loop to read all the lines in this conversation file

                    // Close the input stream
                    objIS.close();

                    // Write the final tags for this specific conversation file
                    strLine = "</td>\n" +
                            "\t\t\t\t</tr>\n" +
                            "\t\t\t</table>\n" +
                            "\t\t</section>";

                    objOS.write(strLine.getBytes());

                } catch (Exception e) {
                    tvStatus.append("\n" + getString(R.string.report_failed) + ": " + e.getMessage());
                    return;
                }

            } // End of IF loop for text files

        } // End of FOR loop for finding all WhatsApp conversation files

        // Write final tags
        try {

            strLine = "</article>\n" +
                    "</body>\n" +
                    "</html>";
            objOS.write(strLine.getBytes());

        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.report_failed) + ": " + e.getMessage());
            return;
        }

        // Close the Output stream
        try {
            objOS.flush();
            objOS.close();
        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.report_failed) + ": " + e.getMessage());
            return;
        }

        // Say it's finished
        tvStatus.append("\n" + getString(R.string.report_end));

        // try to open the HTML file in Android
        Intent objIntent = new Intent(Intent.ACTION_VIEW, objFile.getUri());
        objIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(objIntent);

    } // End of report_create

    /* =================================================================================

     * ROUTINE     : writeInitialReport
     * DESCRIPTION : write the initial HTML tags and CSS styles
     * INPUT       : the OutputStream object to write to
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    private void writeInitialReport(OutputStream pObjOS) {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        try {

            String strLine;

            strLine = "<!DOCTYPE html>\n<html lang='" + getString(R.string.report_language) + "'>\n<head>\n<meta charset='UTF-8'>\n";
            strLine = strLine + "<title>" + getString(R.string.report_title) + "</title>\n";
            strLine = strLine + "<style>\n" +
                    "\thtml,body {\n" +
                    "\t\theight: 100%;\n" +
                    "\t\tbackground-color: white;\n" +
                    "\t\tline-height: 1;\n" +
                    "\t\tfont: 12px/20px Arial;\n" +
                    "\t}\n" +
                    "\n" +
                    "\ttable, th, td {\n" +
                    "\t\tborder: 1px solid black;\n" +
                    "\t\tborder-collapse: collapse;\n" +
                    "\t\tpadding: 2px;\n" +
                    "\t}\n" +
                    "\n" +
                    "\ttable.header tr th, table.header tr td  {\n" +
                    "\t\tfont-size: 120%;\n" +
                    "\t\tpadding: 5px;\n" +
                    "\t\t\n" +
                    "\t}\n" +
                    "\t</style>";

            strLine = strLine + "</head>\n" +
                    "<body>\n" +
                    "\t<header>\n";

            strLine = strLine + "<h1>" + getString(R.string.report_title2) + "</h1>\n";

            strLine = strLine + "<table class=\"header\">\n" +
                    "\t\t\t<tr>\n" +
                    "\t\t\t\t<th>" + getString(R.string.report_organization) + "</th>\n";

            EditText etAux = (EditText) findViewById(R.id.etRepOrganization);
            strLine = strLine + "<td>" + etAux.getText() + "</td>\n";

            strLine = strLine + "</tr>\n" +
                    "\t\t\t<tr>\n" +
                    "\t\t\t\t<th>" + getString(R.string.report_expert) + "</th>\n";

            etAux = (EditText) findViewById(R.id.etRepExpert);
            strLine = strLine + "<td>" + etAux.getText() + "</td>\n";

            strLine = strLine + "</tr>\n" +
                    "\t\t\t<tr>\n" +
                    "\t\t\t\t<th>" +getString(R.string.report_equipment) + "</th>\n";

            etAux = (EditText) findViewById(R.id.etRepEquip);
            strLine = strLine + "<td>" + etAux.getText() + "</td>\n";

            strLine = strLine + "<tr>\n" +
                    "\t\t\t\t<th>" + getString(R.string.report_date) + "</th>\n";

            Date date = new Date();
            java.text.DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(getApplicationContext());
            strLine = strLine + "<td>" + dateFormat.format(date) + "</td>\n</tr>\n";

            strLine = strLine + "</table>\n" +
                    "\t</header>\n";

            pObjOS.write(strLine.getBytes());

        } catch (Exception e) {
            tvStatus.append("\n" + e.getMessage());
            return;
        }

    } // End of writeInitialReport

    /* =================================================================================

     * ROUTINE     : writeContacts
     * DESCRIPTION : write the the contacts from WhatsApp
     * INPUT       : the DocumentFile object where Contacts are
     *               the OutputStream object to write to
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    private void writeContacts(DocumentFile pObjFile, OutputStream pObjOS) {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        String strLine;

        // Write the initial tags for this section
        strLine =
        "\t<article>\n" +
                "\t\t<h2>" + getString(R.string.report_title3) + "</h2>\n" +
                "\t\t<table>\n" +
                "\t\t\t\t<tr>\n" +
                "\t\t\t\t\t<th>" + getString(R.string.report_contact_name) + "</th>\n" +
                "\t\t\t\t\t<th>" + getString(R.string.report_contact_number) + "</th>\n" +
                "\t\t\t\t</tr>\n";

        try {
            pObjOS.write(strLine.getBytes());
        } catch (Exception e) {
            tvStatus.append("\n" + e.getMessage());
            return;
        }

        // Open an inputStream for contacts file
        try {

            // Create the Reading object
            InputStream objIS = getContentResolver().openInputStream(pObjFile.getUri());
            BufferedReader objBR = new BufferedReader(new InputStreamReader(objIS));

            // loop through all the lines in this  file
            String strLineAux = "";
            while ((strLine = objBR.readLine()) != null) {

                String[] line = strLine.split("=");

                if (line.length > 1) {
                    strLineAux = "<tr><td>" + line[0] + "</td><td>" + line[1] + "</td></tr>";
                    pObjOS.write(strLineAux.getBytes());
                }

            } // End of WHILE loop to read all the lines in Contacts file

            // Close the input stream
            objIS.close();

        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.report_failed) + ": " + e.getMessage());
            return;
        }

        // In the end, close the html tags for this section
        strLine = "</table>\n" +
                "\t</article>";

        try {
            pObjOS.write(strLine.getBytes());
        } catch (Exception e) {
            tvStatus.append("\n" + e.getMessage());
            return;
        }

    } // End of writeContacts

}  // End of ReportActivity Class
